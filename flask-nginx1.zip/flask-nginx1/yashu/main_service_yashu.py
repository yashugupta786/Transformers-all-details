from flask import Flask, jsonify, request
import json
print("this is start")

app = Flask(__name__)


@app.route("/classification_yashu",methods=["POST"])
def classification():
    sample = json.loads(request.data)["text"]

    return jsonify({"task":"yashu finish"})


if __name__ == "__main__":
    app.run()
